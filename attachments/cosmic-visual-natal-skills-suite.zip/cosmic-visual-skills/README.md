# Cosmic Visual & Natal Skills Suite

Six independently installable ChatGPT skills:

- cosmic-art-director
- symbolic-illustrator
- ancient-design-studio
- symbolic-chart-designer
- natal-chart-artist
- complete-natal-reading

`packages/<skill>/skill.zip` contains the validated installable package for each skill. `source/` contains editable sources.

The natal skills require supplied or reliably calculated chart placements and explicitly separate chart data from interpretive astrology. The visual skills favor original artwork and distinguish documented historical references from modern reinterpretation.
