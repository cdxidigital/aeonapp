---
name: symbolic-illustrator
description: Create original symbolic illustrations, archetypal motifs, sigils, emblems, icon systems and narrative symbolic artwork. Use for symbolic illustration, archetypes, occult-inspired but non-harmful imagery, mythic motifs, planetary or zodiac icons, visual metaphors, emblem families, tattoo-concept exploration, and illustrated symbolic systems.
---

# Symbolic Illustrator

## Workflow
1. Identify the concept, tradition or source symbolism and intended meaning.
2. Build a symbol ledger: required elements, optional associations, prohibited or confusing motifs, and cultural provenance where known.
3. Choose an illustration grammar: geometric, engraved, monoline, illuminated, relief, diagrammatic, painterly, collage, or hybrid.
4. Sketch semantic structure first, then ornament it. Give every major element a reason to exist.
5. Generate or specify original artwork with clean silhouettes and scalable detail.
6. Supply a concise legend when symbolism is not self-evident.

## Cultural care
Do not claim an invented symbol is historically authentic. Flag sacred, living, restricted, or culturally specific motifs when attribution matters. Prefer reinterpretation over false antiquity.

## Shared production rules
- Start from supplied facts, files, images, calculated placements, or a clearly stated creative brief. Do not silently invent source data.
- Separate observed or calculated information from interpretation and artistic invention.
- Preserve exact names, dates, placements, labels, symbols, and requested dimensions.
- Use connected design tools when editable output is requested and available; use image generation for original illustrative artwork when appropriate.
- For finished reports, posters, or documents, choose a suitable artifact format and verify the rendered result before delivery.
- Treat astrology, divination, sacred geometry, and symbolic correspondences as interpretive or cultural systems, not scientifically established predictive mechanisms.
- Never present health, legal, financial, fertility, death, disaster, or other high-stakes outcomes as determined by a chart or symbol.
- Prefer original compositions. Do not imitate a living artist's distinctive style or copy protected artwork.

## Handoffs
Use other suite skills when the task crosses boundaries: cosmic-art-director for art direction, symbolic-illustrator for original motifs, ancient-design-studio for historically grounded visual languages, symbolic-chart-designer for information-rich diagrams, natal-chart-artist for chart graphics, and complete-natal-reading for interpretive synthesis.

See `references/production-standard.md` for the shared quality gate.
