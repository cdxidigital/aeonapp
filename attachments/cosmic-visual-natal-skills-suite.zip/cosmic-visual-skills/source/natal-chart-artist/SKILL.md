---
name: natal-chart-artist
description: Create polished illustrated natal chart graphics from supplied or reliably calculated astrological placements. Use for natal wheels, zodiac charts, aspect diagrams, house and angle visualizations, planetary glyph layouts, chart posters, report covers, transit comparison graphics, and visually formatted birth-chart information.
---

# Natal Chart Artist

## Required inputs
For a newly calculated natal chart, require birth date, exact or best-known birth time, birthplace, and the requested astrology system when it matters. If placements are supplied, use them directly and identify them as supplied.

## Workflow
1. Establish calculation provenance: supplied placements, trusted ephemeris or tool output, or unverified data.
2. Record zodiac type, house system, coordinates and time-zone handling, and aspect or orb rules when available.
3. Build the wheel as data visualization first: houses, angles, signs, planets, degrees, aspects, and legend.
4. Prevent label collisions and make conjunction clusters readable.
5. Apply the requested visual direction using the other suite skills without altering chart data.
6. Verify placements, degree labels, house cusps, angles, and aspect lines before delivery.

## Accuracy rule
Never calculate astronomical positions by intuition. If no reliable calculation method or supplied placement table is available, request or produce a clearly labeled visual template rather than fabricating placements.

## Shared production rules
- Start from supplied facts, files, images, calculated placements, or a clearly stated creative brief. Do not silently invent source data.
- Separate observed or calculated information from interpretation and artistic invention.
- Preserve exact names, dates, placements, labels, symbols, and requested dimensions.
- Use connected design tools when editable output is requested and available; use image generation for original illustrative artwork when appropriate.
- For finished reports, posters, or documents, choose a suitable artifact format and verify the rendered result before delivery.
- Treat astrology, divination, sacred geometry, and symbolic correspondences as interpretive or cultural systems, not scientifically established predictive mechanisms.
- Never present health, legal, financial, fertility, death, disaster, or other high-stakes outcomes as determined by a chart or symbol.
- Prefer original compositions. Do not imitate a living artist's distinctive style or copy protected artwork.

## Handoffs
Use other suite skills when the task crosses boundaries: cosmic-art-director for art direction, symbolic-illustrator for original motifs, ancient-design-studio for historically grounded visual languages, symbolic-chart-designer for information-rich diagrams, natal-chart-artist for chart graphics, and complete-natal-reading for interpretive synthesis.

See `references/production-standard.md` for the shared quality gate.
