---
name: symbolic-chart-designer
description: Design information-rich symbolic charts, wheels, correspondences, matrices, timelines, maps of concepts and sacred-geometric diagrams. Use for zodiac wheels, planetary correspondence charts, archetype maps, element and modality diagrams, symbolic taxonomies, esoteric reference sheets, relationship diagrams, symbolic charts, and illustrated explanatory infographics.
---

# Symbolic Chart Designer

## Workflow
1. Normalize the data into entities, relationships, hierarchy, cycles, axes, or layers.
2. Select the diagram form because it matches the information, not merely because it looks mystical.
3. Define legend, reading order, labels, glyph set, units, and source notes before decoration.
4. Establish geometry precisely. Use radial layouts for cycles, matrices for cross-correspondence, timelines for sequence, and networks only when relationships are genuinely non-linear.
5. Add symbolic ornament after the informational layer is readable.
6. Verify every label and relationship against supplied data or the cited traditional system.

## Formatting
Design for the final medium. Keep small text out of generated raster artwork when an editable layout tool can place it more reliably.

## Shared production rules
- Start from supplied facts, files, images, calculated placements, or a clearly stated creative brief. Do not silently invent source data.
- Separate observed or calculated information from interpretation and artistic invention.
- Preserve exact names, dates, placements, labels, symbols, and requested dimensions.
- Use connected design tools when editable output is requested and available; use image generation for original illustrative artwork when appropriate.
- For finished reports, posters, or documents, choose a suitable artifact format and verify the rendered result before delivery.
- Treat astrology, divination, sacred geometry, and symbolic correspondences as interpretive or cultural systems, not scientifically established predictive mechanisms.
- Never present health, legal, financial, fertility, death, disaster, or other high-stakes outcomes as determined by a chart or symbol.
- Prefer original compositions. Do not imitate a living artist's distinctive style or copy protected artwork.

## Handoffs
Use other suite skills when the task crosses boundaries: cosmic-art-director for art direction, symbolic-illustrator for original motifs, ancient-design-studio for historically grounded visual languages, symbolic-chart-designer for information-rich diagrams, natal-chart-artist for chart graphics, and complete-natal-reading for interpretive synthesis.

See `references/production-standard.md` for the shared quality gate.
