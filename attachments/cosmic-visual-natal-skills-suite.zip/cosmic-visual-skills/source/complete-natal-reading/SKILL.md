---
name: complete-natal-reading
description: Produce complete, structured and optionally illustrated natal-chart readings from supplied or reliably calculated chart data. Use for full birth-chart readings, planet-sign-house interpretation, angles, aspects, chart ruler, element and modality balance, patterns, dominant themes, strengths, tensions, relationships, vocation themes, life-cycle reflection, and polished illustrated astrology reports.
---

# Complete Natal Reading

## Required inputs
Use a verified placement table or natal chart calculation. For a new calculation require birth date, birth time, birthplace, and any requested zodiac or house system. Mark uncertain birth times and explain which interpretations become unreliable.

## Reading architecture
1. Begin with calculation provenance and chart settings.
2. Give a concise whole-chart synthesis before individual placements.
3. Interpret Sun, Moon, Ascendant, chart ruler, personal planets, social planets, outer planets, houses, and angles.
4. Interpret major aspects in context rather than as isolated cookbook statements.
5. Synthesize element, modality, hemisphere, angularity, stellia, aspect patterns, dignities, or other requested frameworks only when supported by the data.
6. Cover relationships, creative expression, work or vocation, growth tensions, and recurring themes as reflective lenses, not deterministic forecasts.
7. End with an integrated summary and practical reflection prompts.

## Illustrated report mode
Coordinate with natal-chart-artist, symbolic-chart-designer, and cosmic-art-director to create a coherent report. Use diagrams where they explain the chart better than prose. Clearly separate chart facts from interpretive text.

## Shared production rules
- Start from supplied facts, files, images, calculated placements, or a clearly stated creative brief. Do not silently invent source data.
- Separate observed or calculated information from interpretation and artistic invention.
- Preserve exact names, dates, placements, labels, symbols, and requested dimensions.
- Use connected design tools when editable output is requested and available; use image generation for original illustrative artwork when appropriate.
- For finished reports, posters, or documents, choose a suitable artifact format and verify the rendered result before delivery.
- Treat astrology, divination, sacred geometry, and symbolic correspondences as interpretive or cultural systems, not scientifically established predictive mechanisms.
- Never present health, legal, financial, fertility, death, disaster, or other high-stakes outcomes as determined by a chart or symbol.
- Prefer original compositions. Do not imitate a living artist's distinctive style or copy protected artwork.

## Handoffs
Use other suite skills when the task crosses boundaries: cosmic-art-director for art direction, symbolic-illustrator for original motifs, ancient-design-studio for historically grounded visual languages, symbolic-chart-designer for information-rich diagrams, natal-chart-artist for chart graphics, and complete-natal-reading for interpretive synthesis.

See `references/production-standard.md` for the shared quality gate.
