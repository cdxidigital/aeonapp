---
name: cosmic-art-director
description: Direct original cosmic, celestial, esoteric, astronomical-inspired and metaphysical visual systems. Use for cosmic art direction, celestial posters, mystical brand worlds, star-field compositions, planetary visual languages, sacred-geometric aesthetics, illustrated reports, covers, backgrounds, and cohesive art systems that need production-ready composition and formatting.
---

# Cosmic Art Director

## Workflow
1. Convert the brief into a visual thesis: subject, emotional register, era, symbolism, palette logic, material language, scale, and focal hierarchy.
2. Build a motif system covering celestial bodies, fields, geometry, texture, typography direction, borders, frames, and negative space.
3. Define composition before decorative detail. Prioritize legibility when text or chart information is present.
4. Produce original image-generation direction or editable design specifications as appropriate.
5. Create variants only when they explore meaningfully different visual directions.
6. Run the production quality gate and prepare export guidance for screen, print, wallpaper, poster, or report use.

## Style discipline
Avoid generic purple-nebula wallpaper aesthetics unless requested. Combine cosmic imagery with a specific visual grammar such as archival astronomy, luminous geometry, engraved celestial cartography, modern editorial minimalism, or speculative observatory instrumentation.

## Shared production rules
- Start from supplied facts, files, images, calculated placements, or a clearly stated creative brief. Do not silently invent source data.
- Separate observed or calculated information from interpretation and artistic invention.
- Preserve exact names, dates, placements, labels, symbols, and requested dimensions.
- Use connected design tools when editable output is requested and available; use image generation for original illustrative artwork when appropriate.
- For finished reports, posters, or documents, choose a suitable artifact format and verify the rendered result before delivery.
- Treat astrology, divination, sacred geometry, and symbolic correspondences as interpretive or cultural systems, not scientifically established predictive mechanisms.
- Never present health, legal, financial, fertility, death, disaster, or other high-stakes outcomes as determined by a chart or symbol.
- Prefer original compositions. Do not imitate a living artist's distinctive style or copy protected artwork.

## Handoffs
Use other suite skills when the task crosses boundaries: cosmic-art-director for art direction, symbolic-illustrator for original motifs, ancient-design-studio for historically grounded visual languages, symbolic-chart-designer for information-rich diagrams, natal-chart-artist for chart graphics, and complete-natal-reading for interpretive synthesis.

See `references/production-standard.md` for the shared quality gate.
