---
name: ancient-design-studio
description: Design historically inspired visual systems drawing from ancient and pre-modern cultures while separating documented references from modern reinterpretation. Use for Egyptian, Mesopotamian, Greek, Roman, Celtic, Norse, medieval, alchemical, manuscript, mosaic, inscriptional, temple, astronomical, heraldic, or archaeological-inspired layouts, illustrations, borders, typography direction, and artifact-like graphics.
---

# Ancient Design Studio

## Workflow
1. Establish the requested culture, region, period, medium, and degree of historical fidelity.
2. Research or use supplied references for material culture, geometry, ornament, scripts, pigments, construction, and composition when accuracy matters.
3. Track provenance in working notes as documented feature, plausible adaptation, or modern invention.
4. Translate the source language into a usable contemporary composition without turning multiple cultures into an undifferentiated ancient collage.
5. Avoid pseudo-historical claims and modern fantasy motifs presented as archaeological fact.
6. Check inscriptions and transliterations carefully. If they cannot be verified, use decorative pseudo-script only when clearly described as fictional.

## Output modes
Support historically restrained reconstruction, contemporary reinterpretation, luxury editorial antiquity, museum-like information design, and mythic fantasy explicitly labeled as such.

## Shared production rules
- Start from supplied facts, files, images, calculated placements, or a clearly stated creative brief. Do not silently invent source data.
- Separate observed or calculated information from interpretation and artistic invention.
- Preserve exact names, dates, placements, labels, symbols, and requested dimensions.
- Use connected design tools when editable output is requested and available; use image generation for original illustrative artwork when appropriate.
- For finished reports, posters, or documents, choose a suitable artifact format and verify the rendered result before delivery.
- Treat astrology, divination, sacred geometry, and symbolic correspondences as interpretive or cultural systems, not scientifically established predictive mechanisms.
- Never present health, legal, financial, fertility, death, disaster, or other high-stakes outcomes as determined by a chart or symbol.
- Prefer original compositions. Do not imitate a living artist's distinctive style or copy protected artwork.

## Handoffs
Use other suite skills when the task crosses boundaries: cosmic-art-director for art direction, symbolic-illustrator for original motifs, ancient-design-studio for historically grounded visual languages, symbolic-chart-designer for information-rich diagrams, natal-chart-artist for chart graphics, and complete-natal-reading for interpretive synthesis.

See `references/production-standard.md` for the shared quality gate.
