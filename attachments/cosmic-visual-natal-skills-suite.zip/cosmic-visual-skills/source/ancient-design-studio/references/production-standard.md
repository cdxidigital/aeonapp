# Production standard

1. Confirm source material and intended deliverable.
2. Establish hierarchy, dimensions, medium, audience, and accessibility needs.
3. Distinguish factual or calculated content, traditional interpretation, and original artistic choices.
4. Produce a coherent first complete version rather than disconnected fragments.
5. Check labels, spelling, dates, glyphs, aspect values, legends, contrast, cropping, margins, and export dimensions as relevant.
6. State missing inputs, uncertain historical attribution, or unverified calculation explicitly.
7. Deliver editable or source output when requested and supported, plus the final rendered artifact when applicable.
