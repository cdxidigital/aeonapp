# AEON Skills Library: astronomy and esoteric interpretation

This collection contains **14 independent ChatGPT Skills** in two families:
- Astronomy: seven evidence-based astronomy and space-science workflows.
- Esoteric: seven interpretive spiritual/cultural study workflows.

## Installing

1. Extract the desired collection archive.
2. Find the desired skill's `skill.zip` in the named folder.
3. Upload/import that individual `skill.zip` as one Skill using the supported Skills uploader. Do **not** upload the collection archive as a single Skill. Repeat for each Skill you wish to use.
4. Review its `SKILL.md` and adjust its reference methods or outputs if preferred.

Each `skill.zip` contains one top-level folder, a validated `SKILL.md`, `agents/openai.yaml`, domain-specific references and, where beneficial, a tested computation helper.

Astronomical results should be supported by observatory/mission/catalog evidence, with dates and uncertainties. Esoteric descriptions are symbolic and historical, and are not empirically proven methods of forecasting a person's future.

## Individual packages

| Family | Skill | Distribution path |
| --- | --- | --- |
| astronomy | Astronomical Data Research | `astronomy/astronomical-data-research/skill.zip` |
| astronomy | Cosmology and Universe | `astronomy/cosmology-universe/skill.zip` |
| astronomy | Exoplanets and Astrobiology | `astronomy/exoplanets-astrobiology/skill.zip` |
| astronomy | Minor Bodies and Orbits | `astronomy/minor-bodies-orbits/skill.zip` |
| astronomy | Night Sky Observer | `astronomy/night-sky-observer/skill.zip` |
| astronomy | Solar System Atlas | `astronomy/solar-system-atlas/skill.zip` |
| astronomy | Stars and Deep Sky Explorer | `astronomy/stellar-deep-sky/skill.zip` |
| esoteric | AEON Esoteric Synthesis | `esoteric/aeon-esoteric-synthesis/skill.zip` |
| esoteric | Astrology Chart Interpreter | `esoteric/astrology-chart-interpreter/skill.zip` |
| esoteric | Esoteric Symbology | `esoteric/esoteric-symbology/skill.zip` |
| esoteric | Human Design Bodygraph | `esoteric/human-design-bodygraph/skill.zip` |
| esoteric | Numerology Profile Engine | `esoteric/numerology-profile-engine/skill.zip` |
| esoteric | Occult Rituals and Magick | `esoteric/occult-magick-practitioner/skill.zip` |
| esoteric | Palmistry Visual Reader | `esoteric/palmistry-visual-reader/skill.zip` |

## AEON architecture suggestion

Keep astronomy data (time, coordinates, ephemerides, observed measurements) separate from symbolic engines (astrology, numerology, Human Design). An integration UI can present both but must not imply that one validates the other.

## Validation

All packages were checked with `package_skill.py`, and test scripts were executed against sample inputs as part of this build.
